import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk  

quiz_data= {
    "General Knowledge": [
         {
            "question": "What is the capital of Australia?",
            "options": ["Sydney", "Melbourne", "Canberra", "Brisbane"],
            "answer": "Canberra"
        },
        {
            "question": "Who invented the telephone?",
            "options": ["Alexander Graham Bell", "Thomas Edison", "Nikola Tesla", "Isaac Newton"],
            "answer": "Alexander Graham Bell"
        },
        {
            "question": "What does 'www' stand for in a website browser?",
            "options": ["World Wide Web", "Web World Wide", "World Web Window", "Wide World Web"],
            "answer": "World Wide Web"
        },
        {
            "question": "Which planet is known as the Red Planet?",
            "options": ["Earth", "Mars", "Jupiter", "Venus"],
            "answer": "Mars"
        },
        {
            "question": "In which year did India become independent?",
            "options": ["1945", "1947", "1950", "1952"],
            "answer": "1947"
        },
        {
            "question": "Who is the current Secretary-General of the United Nations?",
            "options": ["António Guterres", "Ban Ki-moon", "Kofi Annan", "Tedros Adhanom"],
            "answer": "António Guterres"
        },
        {
            "question": "What is the national sport of Canada?",
            "options": ["Ice Hockey", "Basketball", "Lacrosse", "Baseball"],
            "answer": "Lacrosse"
        },
        {
            "question": "Which continent is the largest by area?",
            "options": ["Africa", "Asia", "Europe", "North America"],
            "answer": "Asia"
        },
        {
            "question": "Which gas is most abundant in Earth's atmosphere?",
            "options": ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"],
            "answer": "Nitrogen"
        },
        {
            "question": "Who wrote the national anthem of India?",
            "options": ["Bankim Chandra Chatterjee", "Rabindranath Tagore", "Sarojini Naidu", "Subhash Chandra Bose"],
            "answer": "Rabindranath Tagore"
        },
        {
            "question": "What is the smallest country in the world?",
            "options": ["Monaco", "Nauru", "Maldives", "Vatican City"],
            "answer": "Vatican City"
        },
        {
            "question": "What is the currency of Japan?",
            "options": ["Yuan", "Won", "Yen", "Baht"],
            "answer": "Yen"
        },
        {
            "question": "Where is the Great Barrier Reef located?",
            "options": ["Australia", "Brazil", "Indonesia", "South Africa"],
            "answer": "Australia"
        },
        {
            "question": "Which bird is known for mimicking sounds?",
            "options": ["Parrot", "Peacock", "Owl", "Eagle"],
            "answer": "Parrot"
        },
        {
            "question": "Which animal is the largest mammal?",
            "options": ["African Elephant", "Blue Whale", "Giraffe", "Hippopotamus"],
            "answer": "Blue Whale"
        },
        {
            "question": "What is the tallest mountain in the world?",
            "options": ["K2", "Mount Kilimanjaro", "Mount Everest", "Mount Elbrus"],
            "answer": "Mount Everest"
        },
        {
            "question": "Which country is known as the Land of the Rising Sun?",
            "options": ["China", "Japan", "Thailand", "South Korea"],
            "answer": "Japan"
        },
        {
            "question": "Who was the first person to walk on the Moon?",
            "options": ["Yuri Gagarin", "Buzz Aldrin", "Neil Armstrong", "Michael Collins"],
            "answer": "Neil Armstrong"
        },
        {
            "question": "What is the name of the longest river in the world?",
            "options": ["Amazon", "Nile", "Yangtze", "Mississippi"],
            "answer": "Nile"
        },
        {
            "question": "Who is known as the 'Father of Computers'?",
            "options": ["Alan Turing", "Charles Babbage", "Bill Gates", "Steve Jobs"],
            "answer": "Charles Babbage"
        }
    ],
    "Science": [
         {
            "question": "What is the chemical symbol for water?",
            "options": ["O2", "H2O", "CO2", "NaCl"],
            "answer": "H2O"
        },
        {
            "question": "What part of the cell contains DNA?",
            "options": ["Cytoplasm", "Nucleus", "Ribosome", "Mitochondria"],
            "answer": "Nucleus"
        },
        {
            "question": "What is the speed of light?",
            "options": ["3,000 km/s", "300,000 km/s", "150,000 km/s", "3,000 m/s"],
            "answer": "300,000 km/s"
        },
        {
            "question": "Which gas is essential for human respiration?",
            "options": ["Hydrogen", "Nitrogen", "Oxygen", "Carbon Dioxide"],
            "answer": "Oxygen"
        },
        {
            "question": "What planet has the most moons?",
            "options": ["Earth", "Mars", "Jupiter", "Saturn"],
            "answer": "Saturn"
        },
        {
            "question": "What is the basic unit of life?",
            "options": ["Atom", "Molecule", "Cell", "Tissue"],
            "answer": "Cell"
        },
        {
            "question": "Which vitamin is produced when skin is exposed to sunlight?",
            "options": ["Vitamin A", "Vitamin B12", "Vitamin D", "Vitamin C"],
            "answer": "Vitamin D"
        },
        {
            "question": "Who proposed the theory of relativity?",
            "options": ["Isaac Newton", "Albert Einstein", "Galileo Galilei", "Stephen Hawking"],
            "answer": "Albert Einstein"
        },
        {
            "question": "What does DNA stand for?",
            "options": ["Dynamic Nuclear Atom", "Deoxyribonucleic Acid", "Deoxyribose Nucleic Acid", "Dioxide Nucleotide Acid"],
            "answer": "Deoxyribonucleic Acid"
        },
        {
            "question": "What is the boiling point of water in Celsius?",
            "options": ["0°C", "50°C", "100°C", "212°C"],
            "answer": "100°C"
        },
        {
            "question": "What organ in the human body produces insulin?",
            "options": ["Liver", "Kidney", "Pancreas", "Stomach"],
            "answer": "Pancreas"
        },
        {
            "question": "What is Newton's Third Law?",
            "options": [
                "An object in motion stays in motion",
                "Force equals mass times acceleration",
                "For every action, there is an equal and opposite reaction",
                "Gravity attracts objects toward Earth"
            ],
            "answer": "For every action, there is an equal and opposite reaction"
        },
        {
            "question": "What is the hardest natural substance on Earth?",
            "options": ["Gold", "Iron", "Diamond", "Quartz"],
            "answer": "Diamond"
        },
        {
            "question": "What is the powerhouse of the cell?",
            "options": ["Nucleus", "Mitochondria", "Chloroplast", "Ribosome"],
            "answer": "Mitochondria"
        },
        {
            "question": "What gas do plants absorb from the atmosphere?",
            "options": ["Oxygen", "Carbon Monoxide", "Carbon Dioxide", "Nitrogen"],
            "answer": "Carbon Dioxide"
        },
        {
            "question": "What are the three states of matter?",
            "options": ["Solid, Foam, Gas", "Liquid, Gas, Plasma", "Solid, Liquid, Gas", "Atom, Molecule, Plasma"],
            "answer": "Solid, Liquid, Gas"
        },
        {
            "question": "What is the main function of red blood cells?",
            "options": ["Fight infection", "Digest food", "Transport oxygen", "Produce hormones"],
            "answer": "Transport oxygen"
        },
        {
            "question": "What is the pH level of pure water?",
            "options": ["6", "5", "8", "7"],
            "answer": "7"
        },
        {
            "question": "What is the unit of electric current?",
            "options": ["Ohm", "Ampere", "Volt", "Watt"],
            "answer": "Ampere"
        },
        {
            "question": "Which part of the brain controls balance?",
            "options": ["Cerebrum", "Cerebellum", "Medulla", "Brainstem"],
            "answer": "Cerebellum"
        }
    ],
    "Technology": [
        {
            "question": "Who is the founder of Microsoft?",
            "options": ["Steve Jobs", "Bill Gates", "Elon Musk", "Mark Zuckerberg"],
            "answer": "Bill Gates"
        },
        {
            "question": "Which programming language is used for web apps?",
            "options": ["Python", "Java", "HTML", "C++"],
            "answer": "HTML"
        },
        {
            "question": "What does 'HTTP' stand for?",
            "options": ["HyperText Transfer Protocol", "HyperText Translate Protocol", "High Transfer Text Protocol", "Hyperlink Transfer Protocol"],
            "answer": "HyperText Transfer Protocol"
        },
        {
            "question": "Which company developed the Android OS?",
            "options": ["Apple", "Microsoft", "Google", "Samsung"],
            "answer": "Google"
        },
        {
            "question": "What is the name of Apple’s voice assistant?",
            "options": ["Alexa", "Cortana", "Google Assistant", "Siri"],
            "answer": "Siri"
        }
    ],
    "Mathematics": [
         {
            "question": "What is the square root of 144?",
            "options": ["10", "12", "14", "16"],
            "answer": "12"
        },
        {
            "question": "What is the value of pi (π) to two decimal places?",
            "options": ["3.14", "3.13", "3.15", "3.12"],
            "answer": "3.14"
        },
        {
            "question": "Solve: 8 + (3 × 4)",
            "options": ["20", "24", "18", "16"],
            "answer": "20"
        },
        {
            "question": "What is the perimeter of a square with side 5 cm?",
            "options": ["10 cm", "20 cm", "25 cm", "15 cm"],
            "answer": "20 cm"
        },
        {
            "question": "What is 25% of 200?",
            "options": ["30", "40", "50", "60"],
            "answer": "50"
        },
        {
            "question": "Solve for x: 2x + 5 = 15",
            "options": ["10", "4", "5", "6"],
            "answer": "5"
        },
        {
            "question": "What is the formula for the area of a triangle?",
            "options": ["base × height", "½ × base × height", "base + height", "base² + height²"],
            "answer": "½ × base × height"
        },
        {
            "question": "What is the next prime number after 7?",
            "options": ["9", "10", "11", "13"],
            "answer": "11"
        },
        {
            "question": "How many degrees are there in a right angle?",
            "options": ["180°", "90°", "45°", "360°"],
            "answer": "90°"
        },
        {
            "question": "What is 3 cubed (3³)?",
            "options": ["6", "9", "27", "81"],
            "answer": "27"
        },
        {
            "question": "Convert 0.75 into a fraction.",
            "options": ["1/2", "3/4", "2/3", "1/4"],
            "answer": "3/4"
        },
        {
            "question": "What is the LCM of 4 and 5?",
            "options": ["9", "10", "15", "20"],
            "answer": "20"
        },
        {
            "question": "How many sides does a hexagon have?",
            "options": ["5", "6", "7", "8"],
            "answer": "6"
        },
        {
            "question": "Solve: 100 ÷ 4 + 5",
            "options": ["30", "35", "40", "25"],
            "answer": "30"
        },
        {
            "question": "What is the factorial of 5 (5!)?",
            "options": ["120", "25", "100", "60"],
            "answer": "120"
        },
        {
            "question": "What is the average of 4, 8, and 12?",
            "options": ["10", "6", "8", "9"],
            "answer": "8"
        },
        {
            "question": "Find the missing number: 2, 4, 8, 16, ___",
            "options": ["18", "20", "24", "32"],
            "answer": "32"
        },
        {
            "question": "What is the slope of a line in y = 2x + 3?",
            "options": ["2", "3", "1", "0"],
            "answer": "2"
        },
        {
            "question": "What is the probability of flipping a coin and getting heads?",
            "options": ["1/4", "1/3", "1/2", "1"],
            "answer": "1/2"
        },
        {
            "question": "Solve: (5² + 2²) ÷ 3",
            "options": ["31", "11", "9", "10"],
            "answer": "11"
        }
    ],
    "History": [
        {
            "question": "Who was the first President of the United States?",
            "options": ["Thomas Jefferson", "Abraham Lincoln", "George Washington", "John Adams"],
            "answer": "George Washington"
        },
        {
            "question": "When did World War II end?",
            "options": ["1940", "1945", "1939", "1950"],
            "answer": "1945"
        },
        {
            "question": "Who was the founder of the Mughal Empire?",
            "options": ["Akbar", "Humayun", "Babur", "Shah Jahan"],
            "answer": "Babur"
        },
        {
            "question": "In which year was the Constitution of India adopted?",
            "options": ["1947", "1949", "1950", "1952"],
            "answer": "1949"
        },
        {
            "question": "Who discovered America?",
            "options": ["Vasco da Gama", "Ferdinand Magellan", "Christopher Columbus", "Amerigo Vespucci"],
            "answer": "Christopher Columbus"
        },
        {
            "question": "What was the name of the ship on which the Pilgrims traveled to America?",
            "options": ["Titanic", "Mayflower", "Santa Maria", "Victoria"],
            "answer": "Mayflower"
        },
        {
            "question": "Who was the first woman Prime Minister of India?",
            "options": ["Pratibha Patil", "Sarojini Naidu", "Indira Gandhi", "Sonia Gandhi"],
            "answer": "Indira Gandhi"
        },
        {
            "question": "What event started World War I?",
            "options": [
                "Assassination of Abraham Lincoln",
                "Bombing of Hiroshima",
                "Assassination of Archduke Franz Ferdinand",
                "Invasion of Poland"
            ],
            "answer": "Assassination of Archduke Franz Ferdinand"
        },
        {
            "question": "Who led the Salt March in India?",
            "options": ["Jawaharlal Nehru", "Subhas Chandra Bose", "Bhagat Singh", "Mahatma Gandhi"],
            "answer": "Mahatma Gandhi"
        },
        {
            "question": "What was the Cold War?",
            "options": [
                "A war fought during winter",
                "A conflict between North and South Korea",
                "A political and ideological conflict between the USA and USSR",
                "A war in Antarctica"
            ],
            "answer": "A political and ideological conflict between the USA and USSR"
        },
        {
            "question": "Which empire built the Colosseum?",
            "options": ["Greek Empire", "Egyptian Empire", "Roman Empire", "Persian Empire"],
            "answer": "Roman Empire"
        },
        {
            "question": "Who was Napoleon Bonaparte?",
            "options": [
                "A French military leader and emperor",
                "An Italian scientist",
                "A Spanish king",
                "A British philosopher"
            ],
            "answer": "A French military leader and emperor"
        },
        {
            "question": "When was the Berlin Wall torn down?",
            "options": ["1985", "1987", "1989", "1991"],
            "answer": "1989"
        },
        {
            "question": "Who assassinated Mahatma Gandhi?",
            "options": ["Nathuram Godse", "Subhas Chandra Bose", "General Dyer", "Bhagat Singh"],
            "answer": "Nathuram Godse"
        },
        {
            "question": "Which Indian king is known for his Kalinga war?",
            "options": ["Chandragupta Maurya", "Harshavardhana", "Ashoka", "Samudragupta"],
            "answer": "Ashoka"
        },
        {
            "question": "Who was Cleopatra?",
            "options": ["A Roman Empress", "An Egyptian queen", "A Greek warrior", "A Mesopotamian goddess"],
            "answer": "An Egyptian queen"
        },
        {
            "question": "What ancient civilization built the pyramids?",
            "options": ["Romans", "Greeks", "Egyptians", "Babylonians"],
            "answer": "Egyptians"
        },
        {
            "question": "Who was the first human in space?",
            "options": ["Neil Armstrong", "Yuri Gagarin", "Buzz Aldrin", "Alan Shepard"],
            "answer": "Yuri Gagarin"
        },
        {
            "question": "Which war was fought between the North and South in the United States?",
            "options": [
                "American Revolutionary War",
                "Civil War",
                "World War I",
                "War of 1812"
            ],
            "answer": "Civil War"
        },
        {
            "question": "What treaty ended World War I?",
            "options": [
                "Treaty of Versailles",
                "Treaty of Paris",
                "Treaty of Tordesillas",
                "Treaty of Ghent"
            ],
            "answer": "Treaty of Versailles"
        }
    ],
    "Current Affairs": [
        {
            "question": "Who is the current Prime Minister of India?",
            "options": ["Manmohan Singh", "Rahul Gandhi", "Narendra Modi", "Arvind Kejriwal"],
            "answer": "Narendra Modi"
        },
        {
            "question": "Which country hosted the G20 summit in 2024?",
            "options": ["India", "Brazil", "Italy", "Japan"],
            "answer": "Brazil"
        },
        {
            "question": "What major tech company launched a new AI chip in 2025?",
            "options": ["Intel", "AMD", "Nvidia", "Apple"],
            "answer": "AMD"
        },
        {
            "question": "Who won the ICC Men’s Cricket World Cup 2023?",
            "options": ["India", "Australia", "England", "New Zealand"],
            "answer": "Australia"
        },
        {
            "question": "What is the name of India’s latest lunar mission?",
            "options": ["Chandrayaan-2", "Chandrayaan-3", "Gaganyaan", "Aditya-L1"],
            "answer": "Chandrayaan-3"
        },
        {
            "question": "Which country recently joined BRICS in 2024?",
            "options": ["Saudi Arabia", "Egypt", "Argentina", "Turkey"],
            "answer": "Egypt"
        },
        {
            "question": "Who won the 2025 Grammy Award for Album of the Year?",
            "options": ["Taylor Swift", "Kendrick Lamar", "Beyoncé", "The Weeknd"],
            "answer": "Beyoncé"
        },
        {
            "question": "What was the headline topic at COP29 climate conference?",
            "options": ["Global reforestation", "Climate finance", "Technology transfer", "Carbon capture"],
            "answer": "Climate finance"
        },
        {
            "question": "Who is the new CEO of Twitter as of 2025?",
            "options": ["Elon Musk", "Parag Agrawal", "Linda Yaccarino", "Jack Dorsey"],
            "answer": "Linda Yaccarino"
        },
        {
            "question": "What is the name of the cyclone that hit the eastern coast of India in May 2025?",
            "options": ["Cyclone Nisarga", "Cyclone Tauktae", "Cyclone Yaas", "Cyclone Amphan"],
            "answer": "Cyclone Yaas"
        },
        {
            "question": "Which Indian city hosted the 2025 Startup India Global Summit?",
            "options": ["Bengaluru", "Mumbai", "New Delhi", "Hyderabad"],
            "answer": "New Delhi"
        },
        {
            "question": "Which Indian was featured in TIME’s 100 most influential people in 2025?",
            "options": ["Sundar Pichai", "Satya Nadella", "Ratan Tata", "Nirmala Sitharaman"],
            "answer": "Sundar Pichai"
        },
        {
            "question": "What tech innovation is Apple planning to launch in 2025?",
            "options": ["Foldable iPhone", "AR headset", "VR glasses", "AI chip"],
            "answer": "AI chip"
        },
        {
            "question": "Which state won the best performing state award in Swachh Bharat rankings 2025?",
            "options": ["Kerala", "Gujarat", "Haryana", "Maharashtra"],
            "answer": "Gujarat"
        },
        {
            "question": "What is the current Repo Rate set by the RBI (as of June 2025)?",
            "options": ["6.25%", "6.50%", "6.75%", "7.00%"],
            "answer": "6.50%"
        },
        {
            "question": "Who won the 2025 IPL?",
            "options": ["Mumbai Indians", "Chennai Super Kings", "Kolkata Knight Riders", "Sunrisers Hyderabad"],
            "answer": "Kolkata Knight Riders"
        },
        {
            "question": "Which country launched the world’s fastest internet network in 2025?",
            "options": ["USA", "South Korea", "Switzerland", "UAE"],
            "answer": "South Korea"
        },
        {
            "question": "What film won Best Picture at the Oscars 2025?",
            "options": ["The Fabelmans", "Killers of the Flower Moon", "Oppenheimer", "Anatomy of a Fall"],
            "answer": "Anatomy of a Fall"
        },
        {
            "question": "What Indian bank launched AI-based customer support in 2025?",
            "options": ["SBI", "HDFC Bank", "ICICI Bank", "Axis Bank"],
            "answer": "ICICI Bank"
        },
        {
            "question": "What is the name of the AI bill passed in the EU in 2025?",
            "options": ["AI Accountability Act", "Digital Services Act", "AI Act", "Algorithm Transparency Law"],
            "answer": "AI Act"
        }
    ]         
}


# Global variables
current_question = 0
selected_category = ""
score = 0
questions = []
bg_label = None  

# Category to image mapping
category_images = {
    "General Knowledge": "background_gk.png",
    "Science": "background_science.png",
    "Technology": "background_tech.png",
    "Mathematics": "background_math.png",
    "History": "background_history.png",
    "Current Affairs": "background_current_affairs.png"
}

# Start Quiz
def start_quiz():
    global selected_category, questions, current_question, score
    selected_category = category_var.get()
    if selected_category == "":
        messagebox.showwarning("Select Category", "Please select a category to start.")
        return

    # Set questions and reset counters
    questions[:] = quiz_data[selected_category]
    current_question = 0
    score = 0

    # Update background and show quiz
    update_background(selected_category)
    category_frame.pack_forget()
    start_btn.pack_forget()
    title.config(text=f"{selected_category} Quiz")
    quiz_frame.pack(pady=10)
    show_question()

# Show question
def show_question():
    q = questions[current_question]
    question_label.config(text=f"Q{current_question+1}: {q['question']}")
    options_var.set("")
    for i in range(4):
        options[i].config(text=q["options"][i], value=q["options"][i])

# Next question
def next_question():
    global current_question, score
    selected = options_var.get()
    if selected == "":
        messagebox.showwarning("No Selection", "Please select an answer.")
        return

    if selected == questions[current_question]["answer"]:
        score += 1

    current_question += 1
    if current_question < len(questions):
        show_question()
    else:
        show_result()

# Show result
def show_result():
    messagebox.showinfo("Result", f"Quiz Completed!\nYour Score: {score}/{len(questions)}")
    window.destroy()

# Update background
def update_background(category):
    global bg_image
    image_path = category_images.get(category)
    img = Image.open(image_path)
    img = img.resize((500, 400))
    bg_image = ImageTk.PhotoImage(img)
    bg_label.config(image=bg_image)

# GUI setup
window = tk.Tk()
window.title("Quiz Game")
window.geometry("500x400")
window.resizable(False, False)

# Background image placeholder
bg_image = ImageTk.PhotoImage(Image.new("RGB", (500, 400), color="white"))
bg_label = tk.Label(window, image=bg_image)
bg_label.place(x=0, y=0, relwidth=1, relheight=1)

# Title
title = tk.Label(window, text="Quiz Game", font=("Arial", 18, "bold"), bg="white")
title.pack(pady=10)

# Category selection
category_var = tk.StringVar()
category_frame = tk.Frame(window, bg="white")
category_frame.pack(pady=10)
tk.Label(category_frame, text="Choose Category:", font=("Arial", 12), bg="white").pack()

for cat in quiz_data.keys():
    tk.Radiobutton(category_frame, text=cat, variable=category_var, value=cat, font=("Arial", 11), bg="white").pack(anchor='w')

start_btn = tk.Button(window, text="Start Quiz", command=start_quiz, font=("Arial", 12), bg="green", fg="white")
start_btn.pack(pady=10)

# Quiz frame (initially hidden)
quiz_frame = tk.Frame(window, bg="white")

question_label = tk.Label(quiz_frame, text="", font=("Arial", 14), wraplength=400, justify="left", bg="white")
question_label.pack()

options_var = tk.StringVar()
options = []
for i in range(4):
    rb = tk.Radiobutton(quiz_frame, text="", variable=options_var, value="", font=("Arial", 11), bg="white")
    rb.pack(anchor="w")
    options.append(rb)

next_btn = tk.Button(quiz_frame, text="Next", command=next_question, font=("Arial", 12), bg="blue", fg="white")
next_btn.pack(pady=10)

window.mainloop()